<?xml version="1.0" encoding="UTF-8"?>
<tileset name="stats" tilewidth="32" tileheight="32" tilecount="300" columns="20">
 <image source="stats.png" width="640" height="480"/>
</tileset>
