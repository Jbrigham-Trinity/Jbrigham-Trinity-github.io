<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="grassstage2sp" tilewidth="32" tileheight="32" tilecount="1700" columns="50">
 <image source="grassstage2sp.png" width="1600" height="1088"/>
</tileset>
