import pygame
import sys
pygame.init()

pygame.mixer.music.load('023- Earthbound - Home Sweet Home.mp3')
pygame.mixer.music.play(-1,0.0)

   
    
  

soundObj = pygame.mixer.Sound('relaxing_something.ogg')
soundObj.play()
    
    



