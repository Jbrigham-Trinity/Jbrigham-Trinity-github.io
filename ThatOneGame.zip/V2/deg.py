moo = 1
if moo == 'Penis':
    print('That\'s kinda gay')
elif moo == 1:
    print('Kay')
else:
    print("Alexander Hamilton")
    
