<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="grassstage4redux" tilewidth="32" tileheight="32" tilecount="700" columns="35">
 <image source="grassstage4redux.png" width="1120" height="640"/>
</tileset>
