import pygame
import sys
import time
# import from other modules here
class levelstate(self,area,music):
# write programs to handle and remember:
# level state, game data, player inventory, etc.
    def __init__(self,area,music):
        self.area = area
        self.music = area

'''
Hm.
Unused.
It seems that that\'s just the way
that this will play out.
'''
    
