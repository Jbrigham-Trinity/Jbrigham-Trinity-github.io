<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="snowplacev2" tilewidth="32" tileheight="32" tilecount="1440" columns="36">
 <image source="snowplacev2.png" width="1152" height="1280"/>
</tileset>
