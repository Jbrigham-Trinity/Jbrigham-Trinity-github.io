<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="heaven" tilewidth="32" tileheight="32" tilecount="3000" columns="50">
 <image source="heaven.png" width="1600" height="1920"/>
</tileset>
