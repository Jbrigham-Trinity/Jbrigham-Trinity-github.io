<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="grayhouse" tilewidth="32" tileheight="32" tilecount="1230" columns="30">
 <image source="grayhouse.png" width="960" height="1312"/>
</tileset>
