11/20/2021
On the title screen, do not hit
continue unless you know what you're doing.
(there is a save file loaded, and 
I am too lazy to deal with 
proper coding for it atm.)

Move with arrow keys
interact with z
run with x
c
access menus with enter

Click ThatOneGame.exe to begin playing.
